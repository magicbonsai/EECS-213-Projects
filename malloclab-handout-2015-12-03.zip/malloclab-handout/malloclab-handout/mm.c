/*
 * mm-naive.c - The fastest, least memory-efficient malloc package.
 * 
 * In this naive approach, a block is allocated by simply incrementing
 * the brk pointer.  A block is pure payload. There are no headers or
 * footers.  Blocks are never coalesced or reused. Realloc is
 * implemented directly using mm_malloc and mm_free.
 *
 * NOTE TO STUDENTS: Replace this header comment with your own header
 * comment that gives a high level description of your solution.
 */
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <unistd.h>
#include <string.h>

#include "mm.h"
#include "memlib.h"

/*********************************************************
 * NOTE TO STUDENTS: Before you do anything else, please
 * provide your team information in the following struct.
 ********************************************************/
team_t team = {
    /* Team name */
    "Trippy Zhu",
    /* First member's full name */
    "Alexander Zhu",
    /* First member's email address */
    "alexanderzhu2017@u.northwestern.edu",
    /* Second member's full name (leave blank if none) */
    "Samantha Trippy",
    /* Second member's email address (leave blank if none) */
    "samanthatrippy2016@u.northestern.edu"
};

typedef unsigned int class_size;
typedef char byte;
typedef int word;
typedef void* heap_index;

#define FREE_LIST_SEGREGATION 256;

#define LIST_END (void*) 0  
#define NUM_FREE_LISTS 40 

#define FREE 0
#define ALLOCATED 1
#define ALIGNMENT 8 


#define ALIGN(size) (((size) + (ALIGNMENT-1)) & ~0x7)

#define HEAD_SIZE 8
#define FOOT_SIZE 8
#define MINIMUM_SIZE 24 

#define IS_ALLOCATED(x)    (RETRIEVE(HEAD(x)) & 0x1) 
#define IS_FREE(x)     (!IS_ALLOCATED(x))
#define IS_PREV_ALLOCATED(x) ((RETRIEVE(HEAD(x)) & 0x2) == 0x2)
#define IS_NEXT_ALLOCATED(x) (IS_ALLOCATED(NEXT(x)))

#define LOAD_SIZE(x)  (UNPACK_SIZE(HEAD(x))) 
#define COMBINED_SIZE(size) (size + HEAD_SIZE + FOOT_SIZE) 
#define BLOCK_SIZE(x) (COMBINED_SIZE(LOAD_SIZE(x))) 
#define UNPACK_SIZE(x) (RETRIEVE(x) & ~0x7) 

#define NEXT(x) (x + BLOCK_SIZE(x))
#define PREV_FOOTER(x) (HEAD(x) - FOOT_SIZE)
#define PREV(x) (x - COMBINED_SIZE(UNPACK_SIZE(PREV_FOOTER(x))))

#define BOUNDARY_SIZE 0
#define MAKE_BOUNDARY(block) (PLACE(HEADER(block),COMBINE(BOUNDARY_SIZE,ALLOCATED,ALLOCATED)))


#define TAG_SIZE 4
#define COMBINE(size, alloc, alloc_prev) ((size | alloc) | (alloc_prev << 1))

#define PLACE(location, value) (*(word *)(location) = value)
#define RETRIEVE(location)      (*(word *)(location))

#define HEAD(x)  ((void*)(x) - HEAD_SIZE)
#define FOOT(x)  ((void*)(x) + LOAD_SIZE(x))
#define HEAD_LOAD(y) ((void*) y + HEAD_SIZE)


#define MARK_ALLOCATED(x)  (PLACE(HEAD(x),RETRIEVE(HEAD(x)) | 0x1))
#define MARK_FREE(x)   (PLACE(HEAD(x),RETRIEVE(HEAD(x)) & ~0x1))
#define MARK_PREV_ALLOCATED(x) (PLACE(HEAD(x), RETRIEVE(HEAD(x)) | 0x2))
#define MARK_PREV_FREE(x)  (PLACE(HEAD(x), RETRIEVE(HEAD(x)) & ~0x2))

#define CLASS_TO_NUM(class) (class >> 5);
#define FREE_LIST(class) ((void**) (heap_start + (CLASS_TO_NUM(class) * 4)))

#define SET_FREE_LIST(class,block) (*FREE_LIST_NUM(class) = block)

#define FREE_LIST_NUM(num) ((void**) (heap_start + num * 4))


#define NEXT_FREE_BLOCK(x) ((void**) ((void*) HEAD(x) + TAG_SIZE))
#define PREV_FREE_BLOCK(x) ((void**) ((void*) FOOT(x) + TAG_SIZE))
#define GET_NEXT_FREE_BLOCK(x) (*NEXT_FREE_BLOCK(x))
#define GET_PREV_FREE_BLOCK(x) (*PREV_FREE_BLOCK(x))
#define SET_NEXT_FREE_BLOCK(x,next) (GET_NEXT_FREE_BLOCK(x) = next)
#define SET_PREV_FREE_BLOCK(x,prev) (GET_PREV_FREE_BLOCK(x) = prev)



   (i.e., in the block preceding the ending block).
   0 if the last block on the heap is allocated. */
#define END_FREE_SPACE (IS_PREV_ALLOCATED(ending) ? 0 : BLOCK_SIZE(PREV(ending)))
 
void* heap_start;
void* beginning;
void* ending;

static void* find_fit(int size);
static class_size get_class_size(size_t size);
static void* block_new_allocate(size_t size);
static void update_load_size(void* block, size_t size_new);
static void* block_split(void* block, size_t split_size);
static void deleteFromFreeList(void* block);
static void* merge(void* block);
static void addToFreeList(void* block);

/* 
 * mm_init - initialize the malloc package by initializing the pointers to
 * the free lists and initializing the beginning and ending
 */
int mm_init(void)
{

    heap_start = mem_sbrk(NUM_FREE_LISTS * sizeof(void**) + 2*COMBINED_SIZE(BOUNDARY_SIZE));
    void** index_current = heap_start;

  
    int i;
    for (i = 0; i < NUM_FREE_LISTS; i++) {
        *index_current = LIST_END;
        index_current = index_current + 1;
    }

    
    beginning = (void*) index_current + HEAD_SIZE;
    MAKE_BOUNDARY(beginning);
    ending = beginning + COMBINED_SIZE(BOUNDARY_SIZE);
    MAKE_BOUNDARY(ending);
    return 0;
}

/* 
 * mm_malloc - Allocate a block by attempting to find a suitably sized free
 * block in relevant free lists, otherwise allocating a new block, and
 * returning NULL is we are out of memory
 */
void *mm_malloc(size_t size)
{
    int size_new = ALIGN(size);
    
   
    void *p = find_fit(size_new);
    
   
    if (p == NULL)
        p = block_new_allocate(size_new);

    if (p == NULL)
        return p;
        
    
    deleteFromFreeList(p); 
	MARK_ALLOCATED(p); 
	MARK_PREV_ALLOCATED(NEXT(p));
    
    return p;
}

/*
 * mm_free - Free a block by setting it as free, adding it to the relevant
 * free list, and coalescing with adjoining blocks.
 */
void mm_free(void *ptr)
{
    
    MARK_FREE(ptr); 
	MARK_PREV_FREE(NEXT(ptr)); 
	addToFreeList(ptr);
    
    merge(ptr);
}

/*
 * mm_realloc - reallocate memory by handling special cases (when ptr is NULL,
 * size is 0, or we are allocating the same size), and then attempt to use the
 * current memory at and around ptr if possible, otherwise allocating a new
 * block using mm_malloc.  If necessary, copy the data stored at ptr to the
 * new location.
 */
void *mm_realloc(void *ptr, size_t size)
{
    void *ptr_old = ptr;
    void *ptr_new;
    size_t size_old = LOAD_SIZE(ptr_old);
    size_t size_new = ALIGN(size);
    int size_diff = size_new - size_old;

  
    if (!ptr){
        return mm_malloc(size);
    }

  
    else if (!size){
        mm_free(ptr);
        return NULL;
    }


    else if (size_new < size_old / 2){
      
        MARK_FREE(ptr_old); 
		MARK_PREV_FREE(NEXT(ptr_old)); 
		addToFreeList(ptr_old);

        
        ptr_new = block_split(ptr_old, size_new);
        
     
        deleteFromFreeList(ptr_new); 
		MARK_ALLOCATED(ptr_new); 
		MARK_PREV_ALLOCATED(NEXT(ptr_new));
		
        return ptr_new;
    }

   
    else if (size_new <= size_old){
        return ptr_old;
    }


    
    
    else {

        void** prev = PREV(ptr_old);
        void** next = NEXT(ptr_old);
        bool prev_free = IS_FREE(prev);
        bool next_free = IS_FREE(next);
        size_t prev_size = LOAD_SIZE(prev);
        size_t next_size = LOAD_SIZE(next);

       
        if ((next_free && next_size >= size_diff) ||
            (prev_free && prev_size >= size_diff) ||
            (next_free && prev_free && (prev_size + next_size) >= size_diff)){
            
            MARK_FREE(ptr_old); 
			MARK_PREV_FREE(NEXT(ptr_old)); 
			addToFreeList(ptr_old);

         
            ptr_new = merge(ptr_old);

     
            if (ptr_new != ptr_old)
                memcpy(ptr_new, ptr_old, size_old);
            
          
            ptr_new = block_split(ptr_new, size_new);
            deleteFromFreeList(ptr_new); 
			MARK_ALLOCATED(ptr_new); 
			MARK_PREV_ALLOCATED(NEXT(ptr_new));
            return ptr_new;
        }

       
        else {
            ptr_new = mm_malloc(size_new * 2); 
            if (ptr_new == NULL) 
                return NULL;
            memcpy(ptr_new, ptr_old, size_old); 
            mm_free(ptr_old); 
            return ptr_new; 
        }
    }
}



static void* find_fit(int size) 
{

    if (size <= 0)
        return NULL;

    class_size class = get_class_size(size);



    void** list;
    for (list = FREE_LIST_NUM(class); (void*) list < HEAD(beginning); list++) {
      
        void* current_block = *list;
        
       
        while (current_block != LIST_END) {
            
            if (LOAD_SIZE(current_block) >= size)
                return block_split(current_block, size);

            current_block = GET_NEXT_FREE_BLOCK(current_block);
        }
    }


    return NULL;
}


static class_size get_class_size(size_t size) {

    return size/FREE_LIST_SEGREGATION;
}


static void* block_new_allocate(size_t size) {
    size_t block_size = COMBINED_SIZE(size);
    
    size_t size_needed = block_size - END_FREE_SPACE;
        
  
    void* p = mem_sbrk(size_needed);
    
 
    p = ending;
    MARK_FREE(p);    
    update_load_size(p, size_needed - 16);
    addToFreeList(p);

  
    ending += size_needed;
    MAKE_BOUNDARY(ending);
    MARK_PREV_FREE(ending);

   
    p = merge(p);
 
    return block_split(p, size);
}


static void update_load_size(void* block, size_t size_new) {
    word new_tag = COMBINE(size_new,IS_ALLOCATED(block),IS_PREV_ALLOCATED(block));
    PLACE(HEAD(block),new_tag);
    PLACE(FOOT(block),new_tag);
}


static void* block_split(void* block, size_t split_size) {
    size_t initial_size = LOAD_SIZE(block);
    
    if (initial_size >= split_size + MINIMUM_SIZE) {
    
        
        deleteFromFreeList(block);
    
        
        update_load_size(block, split_size);

        
        void* new_block = NEXT(block);
        size_t size_new = initial_size - BLOCK_SIZE(block);
        update_load_size(new_block, size_new);
        MARK_FREE(new_block); 
		MARK_PREV_FREE(NEXT(new_block)); 
		addToFreeList(new_block);
    
    
        addToFreeList(block);
        
  }
  
  return block;
}





static void* merge(void* block) {
    bool prev_allocated = IS_PREV_ALLOCATED(block);
    bool next_allocated = IS_NEXT_ALLOC(block);   
    size_t size = LOAD_SIZE(block);
    
   
    if (prev_allocated && next_allocated) {
        return block;
    }
    
    
    else if (prev_allocated) {
        void* next = NEXT(block);
        
       
        deleteFromFreeList(block);
        deleteFromFreeList(next);
        
    
        size = size + COMBINED_SIZE(LOAD_SIZE(next));
        PLACE(HEAD(block), COMBINE(size,FREE,IS_PREV_ALLOCATED(block)));
        PLACE(FOOT(next), COMBINE(size,FREE,IS_PREV_ALLOCATED(block))); 
        
        addToFreeList(block);
        return block;
    }
    
   
    else if (next_allocated) {
        void* prev = PREV(block);
        
		deleteFromFreeList(prev);
        deleteFromFreeList(block);
       
        size = size + COMBINED_SIZE(LOAD_SIZE(prev));
        PLACE(FOOT(block), COMBINE(size,FREE,IS_PREV_ALLOCATED(prev)));
        PLACE(HEAD(prev), COMBINE(size,FREE,IS_PREV_ALLOCATED(prev)));
        
        addToFreeList(prev);
        return prev;
    }
    
    
    else {
        void* prev = PREV(block);
        void* next = NEXT(block);
        
        // Maintain free lists
        deleteFromFreeList(block);
        deleteFromFreeList(prev);
        deleteFromFreeList(next);
        
        // Update header of PREV so that size stretches encompass BLOCK and NEXT
        size += COMBINED_SIZE(LOAD_SIZE(prev)) + COMBINED_SIZE(LOAD_SIZE(next));
        PLACE(HEAD(prev), COMBINE(size,FREE,IS_PREV_ALLOCATED(prev)));
        PLACE(FOOT(next), COMBINE(size,FREE,IS_PREV_ALLOCATED(prev)));
        
        addToFreeList(prev);
        return prev;
    }
}


static void addToFreeList(void* block){
    class_size class = get_class_size(LOAD_SIZE(block));
    void* head = FREE_LIST_NUM(class);
    
    // Set next pointer of BLOCK to the current free list head
    SET_NEXT_FREE_BLOCK(block,head);

    if (head != LIST_END)
        SET_PREV_FREE_BLOCK(head,block);

    // Head of a list should have the prev free block to point to list end
    SET_PREV_FREE_BLOCK(block, LIST_END);

    // Make the free list's new head BLOCK
    SET_FREE_LIST(class,block);
}

static void deleteFromFreeList(void* block) {
    void* prev = GET_PREV_FREE_BLOCK(block);
    void* next = GET_NEXT_FREE_BLOCK(block);
    
	
    if (prev == LIST_END)
        SET_FREE_LIST(get_class_size(LOAD_SIZE(block)), next);
    else
        SET_NEXT_FREE_BLOCK(prev,next);
    
   
    if (next != LIST_END)
        SET_PREV_FREE_BLOCK(next,prev);
}